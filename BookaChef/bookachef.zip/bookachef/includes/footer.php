
    

    </main>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.16.0/moment.min.js" type="text/javascript"></script>

    <script src="assets/js/bs/bootstrap.bundle.min.js"></script>
    <script src="vendors/@popperjs/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="vendors/fontawesome/all.min.js"></script>
    <script src="assets/js/theme.js"></script>
    <script type="text/javascript" src="assets/js/jquery.daterangepicker.min.js"></script>
    <script type="text/javascript" src="assets/js/handleCounter.js"></script>
    <script type="text/javascript" src="assets/js/jquery.customselect.js"></script>
    <script type="text/javascript" src="assets/js/autofilter.js"></script>
    <script type="text/javascript" src="assets/packages/daterangepicker/daterangepicker.js"></script>
    <script src="assets/js/script.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200;300;400;600;700;900&amp;display=swap" rel="stylesheet">

    <!-- <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script> -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
  
    <script data-src="https://unpkg.com/popper.js@1.14.7/dist/popper.min.js"></script>
    <script src="https://unpkg.com/bootstrap-select@1.13.8/dist/js/bootstrap-select.min.js"></script>
  </body>

</html>