



    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.16.0/moment.min.js" type="text/javascript"></script>

    <script src="../assets/js/bs/bootstrap.bundle.min.js"></script>
    <script src="../vendors/@popperjs/popper.min.js"></script>
    <script src="../vendors/bootstrap/bootstrap.min.js"></script>
    <script src="../vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="../vendors/fontawesome/all.min.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script type="text/javascript" src="../assets/js/jquery.daterangepicker.min.js"></script>
    <script type="text/javascript" src="../assets/js/handleCounter.js"></script>
    <script type="text/javascript" src="../assets/js/jquery.customselect.js"></script>
    <script type="text/javascript" src="../assets/js/autofilter.js"></script>

    <script src="../assets/js/chef.js"></script>


    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200;300;400;600;700;900&amp;display=swap" rel="stylesheet">
  </body>

</html>